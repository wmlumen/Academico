# Índice del paquete: Resistencia de Materiales - 2.º BTCC

Este paquete contiene materiales reproducibles para uso de estudiantes y docentes.

## Archivos principales

1. [Guía del estudiante en Markdown](01_Guia_Estudiante_Resistencia_Materiales_2do_BTCC.md)
2. [Guía del estudiante en Word](01_Guia_Estudiante_Resistencia_Materiales_2do_BTCC.docx)
3. [Ejercitario](02_Ejercitario_Resistencia_Materiales.md)
4. [Rúbricas y correspondencia](03_Rubricas_y_Correspondencia.md)
5. [Planilla de proceso RSA](05_Planilla_Proceso_RSA_Resistencia_Materiales.xlsx)
6. [Notas de reproducción docente](04_Notas_Docente_Reproduccion.md)
7. [Carpeta de gráficos](graficos/)
8. [Script reproducible de gráficos](scripts/generar_graficos_rm.py)

## Secuencia sugerida

Plan anual → guía del estudiante → ejercitario → instrumento de evaluación → planilla de proceso → recuperación y portafolio.
