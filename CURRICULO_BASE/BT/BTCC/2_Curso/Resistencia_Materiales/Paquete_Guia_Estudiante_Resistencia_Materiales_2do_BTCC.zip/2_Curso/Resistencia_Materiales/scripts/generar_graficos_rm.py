"""
Generador reproducible de gráficos para la guía de estudiante de Resistencia de Materiales.
Uso: python generar_graficos_rm.py
Salida: carpeta ../graficos con PNG en alta resolución.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
OUT = Path(__file__).resolve().parent.parent / 'graficos'
OUT.mkdir(parents=True, exist_ok=True)
def save(path):
    plt.tight_layout(); plt.savefig(OUT/path, dpi=220, bbox_inches='tight'); plt.close()
# Ejemplo base: curva tensión-deformación
fig, ax = plt.subplots(figsize=(6,4))
eps = np.linspace(0,0.2,200)
sigma = np.piecewise(eps, [eps<0.03, (eps>=0.03)&(eps<0.06), eps>=0.06], [lambda x: 6000*x, lambda x: 180 + 800*(x-0.03), lambda x: 204 + 80*np.sin((x-0.06)*10)])
ax.plot(eps, sigma, linewidth=2)
ax.axvline(0.03, linestyle='--', linewidth=1); ax.axhline(180, linestyle='--', linewidth=1)
ax.text(0.01,80,'Zona elástica\nσ = E·ε'); ax.text(0.045,205,'fluencia'); ax.text(0.12,230,'zona plástica')
ax.set_xlabel('Deformación unitaria ε'); ax.set_ylabel('Tensión σ')
ax.set_title('Curva tensión-deformación idealizada'); ax.grid(True, alpha=.25)
save('03_curva_tension_deformacion.png')
print('Gráfico de ejemplo generado. Para regenerar todos, usar el archivo fuente principal del paquete.')
