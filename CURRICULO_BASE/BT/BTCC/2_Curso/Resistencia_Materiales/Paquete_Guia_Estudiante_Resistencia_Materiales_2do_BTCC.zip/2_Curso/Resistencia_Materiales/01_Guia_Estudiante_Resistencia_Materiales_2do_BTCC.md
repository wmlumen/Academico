# Guía del estudiante: Resistencia de Materiales

**Bachillerato Técnico en Construcciones Civiles - 2.º curso**  
**Material reproducible para aula, taller y estudio independiente**

## Presentación

Esta guía acompaña el desarrollo anual de la cátedra de Resistencia de Materiales. Está pensada para que el estudiante comprenda cómo actúan las cargas sobre los elementos de una construcción, cómo se representan mediante diagramas y cómo se realizan cálculos básicos para verificar piezas estructurales simples.

El material está organizado por unidades mensuales. Cada unidad incluye teoría breve, fórmulas, gráficos explicados, ejemplos resueltos, ejercitario y criterios de evaluación. Los ejercicios se relacionan con evidencias de proceso, rúbricas y planilla RSA.

## Capacidades orientadoras

Al finalizar el recorrido, el estudiante será capaz de:

1. Interpretar fuerzas, momentos, vínculos y condiciones de equilibrio.
2. Construir diagramas de cuerpo libre y calcular reacciones en apoyos.
3. Determinar tensiones y deformaciones por tracción, compresión, corte y flexión.
4. Relacionar el comportamiento resistente de madera, acero y hormigón armado con situaciones de obra.
5. Elaborar un informe técnico básico y defender el diseño preliminar de una viga o elemento simple.

## Cronograma de trabajo

| Mes | Unidad | Contenidos centrales | Evidencia sugerida |
|---|---|---|---|
| Marzo | Estática I | Fuerza, vector, resultante, diagrama de cuerpo libre | Lista de ejercicios y DCL |
| Abril | Estática II | Momento, vínculos, reacciones y equilibrio | Problemas de equilibrio |
| Mayo | Esfuerzo axial | Tracción, compresión, tensión, deformación y Ley de Hooke | Informe corto de ensayo/simulación |
| Junio | Corte y flexión | Vigas simples, cortante, momento flector y tensiones | Diagramas V-M |
| Julio | Integración | Repaso, corrección de errores y nivelación | Prueba formativa |
| Agosto | Madera y pandeo | Propiedades mecánicas, flexión, esbeltez y estabilidad | Ficha técnica de material |
| Septiembre | Acero | Perfiles, barras, fluencia, seguridad y lectura de tablas | Cálculo de sección simple |
| Octubre | Hormigón armado | Trabajo conjunto acero-hormigón, vigas, columnas y losas | Anteproyecto de viga |
| Noviembre | Proyecto integrador | Diseño preliminar de elemento estructural simple y defensa | Portafolio y defensa oral |


## Unidad 1. Estática básica: fuerzas, vectores y resultantes

**Propósito.** Comprender que una fuerza no se define solamente por su valor numérico: también tiene dirección, sentido y punto de aplicación. En construcción, una carga mal ubicada o mal interpretada puede modificar por completo la respuesta de una viga, una columna o un andamio.

**Ideas clave.**
- Una fuerza se representa como vector.
- La resultante es una fuerza única equivalente a un sistema de fuerzas.
- Un diagrama de cuerpo libre muestra todas las fuerzas externas que actúan sobre un cuerpo aislado.

**Fórmulas básicas.**
- Componentes: Fx = F cos θ; Fy = F sen θ.
- Magnitud de una resultante perpendicular: R = √(Fx² + Fy²).
- Dirección: tan θ = Fy / Fx.

**Gráfico 1: descomposición de una fuerza.** La flecha inclinada representa la fuerza F. Las flechas proyectadas sobre los ejes indican sus componentes horizontal y vertical. Este recurso ayuda a convertir un problema gráfico en ecuaciones.

![Componentes de un vector](graficos/01_componentes_vector.png)

**Gráfico 2: diagrama de cuerpo libre.** La viga se separa mentalmente de su entorno. Se reemplazan los apoyos por reacciones RA y RB, y se ubica la carga P. Este paso es obligatorio antes de calcular.

![Diagrama de cuerpo libre](graficos/02_diagrama_cuerpo_libre_viga.png)

**Ejemplo resuelto.** Una fuerza de 100 N actúa con un ángulo de 30° respecto del eje horizontal. Calcular sus componentes.  
Fx = 100 cos 30° = 86,6 N.  
Fy = 100 sen 30° = 50 N.  
La fuerza equivale a 86,6 N en dirección horizontal y 50 N en dirección vertical.

## Unidad 2. Equilibrio y momentos

**Propósito.** Aplicar las condiciones de equilibrio para calcular reacciones en apoyos y verificar la estabilidad de elementos simples.

**Condiciones de equilibrio en el plano.**
- ΣFx = 0
- ΣFy = 0
- ΣM = 0

**Momento de una fuerza.** El momento mide la tendencia de una fuerza a producir giro. Se calcula como M = F · d, donde d es la distancia perpendicular desde el punto de giro hasta la línea de acción de la fuerza.

**Ejemplo resuelto.** Una viga simplemente apoyada de 4 m tiene una carga puntual de 10 kN en el centro. Por simetría: RA = RB = 5 kN. Verificación: ΣFy = 5 + 5 - 10 = 0.

## Unidad 3. Esfuerzo axial, tensión y deformación

**Propósito.** Reconocer cuándo un elemento trabaja a tracción o compresión, y calcular la tensión normal y la deformación longitudinal.

**Conceptos.**
- Tracción: las fuerzas tienden a alargar la pieza.
- Compresión: las fuerzas tienden a acortar la pieza.
- Tensión normal: σ = N / A.
- Deformación unitaria: ε = ΔL / L.
- Ley de Hooke en zona elástica: σ = E · ε.

![Esfuerzo axial](graficos/04_esfuerzo_axial_barra.png)

**Gráfico 3: curva tensión-deformación.** La primera parte de la curva es aproximadamente recta: allí se aplica la Ley de Hooke. Al superar el límite elástico, el material puede quedar deformado permanentemente.

![Curva tensión-deformación](graficos/03_curva_tension_deformacion.png)

**Ejemplo resuelto.** Una barra de acero soporta N = 20 kN y tiene área A = 400 mm².  
σ = N/A = 20.000 N / 400 mm² = 50 N/mm² = 50 MPa.

## Unidad 4. Corte y flexión en vigas

**Propósito.** Interpretar cómo cambian el esfuerzo cortante y el momento flector a lo largo de una viga.

**Ideas clave.**
- El esfuerzo cortante V se relaciona con la tendencia de una sección a deslizar respecto de otra.
- El momento flector M se relaciona con la curvatura o flexión de la pieza.
- Los diagramas V-M permiten localizar secciones críticas.

![Diagrama cortante puntual](graficos/05_diagrama_cortante_puntual.png)

![Diagrama momento puntual](graficos/06_diagrama_momento_puntual.png)

**Explicación de los gráficos.** En una carga puntual centrada, el cortante cambia de signo en el centro de la viga. El momento flector máximo se produce precisamente en esa zona, donde la pieza requiere mayor capacidad resistente.

![Cortante distribuida](graficos/07_cortante_carga_distribuida.png)

![Momento distribuida](graficos/08_momento_carga_distribuida.png)

**Ejemplo resuelto.** Para una viga simplemente apoyada con carga puntual P en el centro: RA = RB = P/2 y Mmax = P·L/4. Si P = 12 kN y L = 6 m, entonces Mmax = 18 kN·m.

## Unidad 5. Tensiones por flexión

**Propósito.** Relacionar el momento flector con tensiones de tracción y compresión en una sección.

**Fórmula de flexión simple.** σ = M·y / I.  
M es el momento flector, y es la distancia al eje neutro, e I es el momento de inercia de la sección.

![Tensiones por flexión](graficos/09_tensiones_flexion.png)

**Explicación del gráfico.** En flexión, una parte de la sección se comprime y otra se tracciona. Entre ambas aparece el eje neutro, donde la tensión normal teórica es cero.

## Unidad 6. Materiales: madera, acero y hormigón armado

**Propósito.** Comparar el comportamiento resistente de los materiales usados en obras civiles.

**Madera.** Es anisótropa: sus propiedades dependen de la dirección de las fibras. En vigas de madera se debe controlar humedad, nudos, apoyo, flecha y posible pandeo lateral.

**Acero.** Tiene buena resistencia a tracción y compresión. En la construcción se usa en barras, perfiles y armaduras. Debe verificarse fluencia, corrosión, uniones y seguridad durante manipulación.

**Hormigón armado.** Combina hormigón, que trabaja bien a compresión, y acero, que trabaja bien a tracción. En una viga de H°A°, el hormigón suele tomar compresión y las barras inferiores toman tracción.

![Hormigón armado](graficos/11_hormigon_armado_flexion.png)

## Unidad 7. Pandeo y estabilidad

**Propósito.** Reconocer el riesgo de inestabilidad en columnas y piezas esbeltas.

**Idea clave.** Una columna no falla solamente por aplastamiento. Si es muy esbelta, puede desviarse lateralmente y perder estabilidad antes de alcanzar la resistencia máxima del material.

![Pandeo](graficos/10_pandeo_columna.png)

**Criterios de observación en obra.** Revisar verticalidad, arriostramientos, longitud libre, apoyos, cargas excéntricas y deformaciones visibles.

## Unidad 8. Proyecto integrador

**Producto final.** Diseño preliminar y defensa de una viga simplemente apoyada o de un elemento estructural simple de uso didáctico.

**El informe debe contener:**
1. Croquis y datos del problema.
2. Diagrama de cuerpo libre.
3. Cálculo de reacciones.
4. Diagramas de cortante y momento.
5. Verificación básica de tensión o selección de sección.
6. Conclusiones, limitaciones y recomendaciones de seguridad.

![Proceso de resolución](graficos/12_proceso_resolucion.png)


# Ejercitario reproducible de Resistencia de Materiales

## A. Fuerzas, vectores y equilibrio

1. Una fuerza de 80 N actúa a 45°. Calcular Fx y Fy.
2. Dos fuerzas perpendiculares de 60 N y 80 N actúan sobre un punto. Calcular la resultante.
3. Dibujar el diagrama de cuerpo libre de una viga simplemente apoyada con una carga puntual central.
4. Una viga de 5 m tiene una carga de 10 kN a 2 m del apoyo izquierdo. Calcular las reacciones.
5. Calcular el momento de una fuerza de 12 kN ubicada a 1,5 m de un punto de giro.
6. Explicar con un ejemplo la diferencia entre fuerza y momento.
7. Una ménsula de 2 m soporta 5 kN en el extremo libre. Calcular la reacción vertical y el momento en el empotramiento.
8. Verificar si un sistema con ΣFx = 0, ΣFy = 0 y ΣM ≠ 0 está en equilibrio.
9. Proponer tres cargas reales que actúan sobre una estructura de techo.
10. Dibujar un DCL de una escalera apoyada contra una pared, indicando peso, reacciones y fricción.

## B. Esfuerzo axial y Ley de Hooke

11. Una barra de acero de 300 mm² soporta 15 kN. Calcular la tensión normal.
12. Una pieza de madera de 50 mm × 100 mm soporta 20 kN a compresión. Calcular σ.
13. Una barra de 2 m se alarga 1 mm. Calcular la deformación unitaria.
14. Si E = 200 GPa y ε = 0,0005, calcular σ.
15. Explicar por qué una deformación permanente es peligrosa en un elemento estructural.
16. Comparar tracción y compresión con ejemplos de obra.
17. Una barra circular de diámetro 20 mm soporta 25 kN. Calcular el área y la tensión.
18. Investigar qué significa MPa y convertir 1 MPa a N/mm².
19. Diseñar una experiencia simple para observar deformación elástica con una regla flexible.
20. Redactar una conclusión técnica sobre la importancia de la Ley de Hooke.

## C. Corte y flexión

21. Viga simplemente apoyada, L = 6 m, P = 12 kN centrada. Calcular reacciones y Mmax.
22. Viga simplemente apoyada, L = 4 m, carga distribuida w = 3 kN/m. Calcular reacciones y Mmax.
23. Dibujar el diagrama de cortante del ejercicio 21.
24. Dibujar el diagrama de momento del ejercicio 21.
25. Explicar dónde se ubica la sección crítica de una viga con carga puntual central.
26. Una viga con carga distribuida tiene V = 0 en el centro. ¿Qué ocurre con el momento en ese punto?
27. Calcular Mmax para L = 5 m y w = 2 kN/m.
28. Enumerar errores frecuentes al dibujar diagramas V-M.
29. Relacionar el cortante con fisuras inclinadas en vigas de hormigón armado.
30. Redactar una interpretación técnica de un diagrama de momento triangular.

## D. Tensiones por flexión y materiales

31. Para una sección rectangular, explicar qué es el eje neutro.
32. ¿Qué fibras se comprimen y cuáles se traccionan en una viga simplemente apoyada con carga vertical descendente?
33. Una sección tiene I = 8×10⁶ mm⁴, y = 50 mm y M = 2 kN·m. Calcular σ en MPa.
34. Explicar por qué el hormigón armado coloca acero en la zona traccionada.
35. Comparar madera, acero y hormigón armado en una tabla de ventajas y limitaciones.
36. Identificar tres controles visuales para aceptar una madera de uso estructural.
37. Explicar el concepto de fluencia del acero.
38. Dibujar una sección de viga de H°A° y marcar zona comprimida, acero traccionado y eje neutro.
39. Indicar qué ocurre si se reduce el recubrimiento de una armadura.
40. Elaborar una ficha técnica simplificada de un material de construcción.

## E. Pandeo, seguridad y proyecto

41. Explicar con tus palabras qué es pandeo.
42. Mencionar tres maneras de reducir el riesgo de pandeo en una columna esbelta.
43. Observar una obra o imagen y señalar posibles elementos sometidos a compresión.
44. Elaborar un checklist de seguridad para manipular barras de acero.
45. Proponer un procedimiento de trabajo seguro para armar un pequeño modelo de viga.
46. Elegir una viga real del aula/taller y describir sus apoyos y cargas probables.
47. Preparar los datos para un proyecto de viga simple: luz, carga, material y sección.
48. Realizar el DCL y cálculo de reacciones para el proyecto del ejercicio 47.
49. Dibujar diagramas V-M del proyecto elegido.
50. Defender oralmente la solución, indicando supuestos, cálculos y límites.

## Clave orientativa de respuestas numéricas

1. Fx = 56,6 N; Fy = 56,6 N.  
2. R = 100 N.  
4. RA = 6 kN; RB = 4 kN.  
5. M = 18 kN·m.  
7. V = 5 kN; M = 10 kN·m.  
11. σ = 50 MPa.  
12. σ = 4 MPa.  
13. ε = 0,0005.  
14. σ = 100 MPa.  
17. A = 314 mm²; σ ≈ 79,6 MPa.  
21. RA = RB = 6 kN; Mmax = 18 kN·m.  
22. RA = RB = 6 kN; Mmax = 6 kN·m.  
27. Mmax = 6,25 kN·m.  
33. σ = 12,5 MPa.  


# Tabla de correspondencia con rúbricas e instrumentos

## Rúbrica 1. Diagrama de cuerpo libre y equilibrio

| Criterio | Nivel 4 - Logrado destacado | Nivel 3 - Logrado | Nivel 2 - En proceso | Nivel 1 - Inicial |
|---|---|---|---|---|
| Identificación de cargas | Reconoce todas las cargas y sentidos | Reconoce cargas principales | Omite cargas secundarias | No diferencia cargas |
| Representación de apoyos | Reemplaza correctamente vínculos por reacciones | Presenta un error menor | Confunde un apoyo | No representa reacciones |
| Ecuaciones de equilibrio | Plantea y resuelve ΣF y ΣM con unidades | Plantea ecuaciones correctas con detalle incompleto | Requiere guía para plantear | No logra plantear equilibrio |
| Presentación | Orden, unidades y croquis claro | Presentación comprensible | Presentación incompleta | Desorden que impide evaluar |

## Rúbrica 2. Cálculo de esfuerzos y tensiones

| Criterio | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Selección de fórmula | Usa fórmula adecuada y justifica | Usa fórmula adecuada | Duda entre fórmulas | Usa fórmula incorrecta |
| Sustitución de datos | Convierte unidades y ordena datos | Sustituye datos correctamente | Presenta errores de unidades | No organiza datos |
| Resultado | Resultado correcto con unidad e interpretación | Resultado correcto | Error numérico menor | Resultado no válido |
| Análisis técnico | Relaciona resultado con seguridad | Explica brevemente | Explicación parcial | Sin interpretación |

## Rúbrica 3. Diagramas de cortante y momento

| Criterio | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Reacciones iniciales | Calcula reacciones correctamente | Un error menor | Error que afecta parte del diagrama | No calcula reacciones |
| Diagrama V | Forma, signos y valores correctos | Forma correcta con detalle menor | Forma parcial | No representa |
| Diagrama M | Forma, signos y valores correctos | Forma correcta con detalle menor | Forma parcial | No representa |
| Sección crítica | Identifica y explica | Identifica | Identifica con ayuda | No identifica |

## Rúbrica 4. Proyecto integrador

| Criterio | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Planteamiento | Define problema, supuestos, cargas y material | Define problema y datos | Datos incompletos | Problema confuso |
| Desarrollo | Cálculos coherentes, ordenados y verificables | Cálculos suficientes | Cálculos parciales | No desarrolla |
| Producto técnico | Informe con croquis, diagramas y conclusión | Informe completo | Informe incompleto | Entrega mínima |
| Defensa oral | Argumenta con seguridad y lenguaje técnico | Explica lo principal | Lee sin argumentar | No defiende |

## Correspondencia unidad-evidencia-rúbrica

| Unidad | Evidencia | Instrumento | Rúbrica asociada |
|---|---|---|---|
| Estática I | DCL de sistemas simples | Lista de cotejo | Rúbrica 1 |
| Estática II | Problemas de reacciones | Prueba práctica | Rúbrica 1 |
| Esfuerzo axial | Cálculo de σ y ε | Ejercitario revisado | Rúbrica 2 |
| Corte y flexión | Diagramas V-M | Rúbrica analítica | Rúbrica 3 |
| Materiales | Ficha técnica comparativa | Portafolio | Rúbrica 2 |
| Hormigón armado | Sección explicada | Exposición corta | Rúbrica 4 |
| Proyecto integrador | Informe y defensa | Rúbrica de proyecto | Rúbrica 4 |

## Lista de cotejo de proceso / RSA

| Indicador | Sí | En proceso | No | Observación |
|---|---|---|---|---|
| Trae materiales y carpeta de trabajo |  |  |  |  |
| Realiza croquis/DCL antes de calcular |  |  |  |  |
| Usa unidades correctas |  |  |  |  |
| Corrige errores después de la retroalimentación |  |  |  |  |
| Participa en prácticas y trabajo colaborativo |  |  |  |  |
| Respeta normas de seguridad en aula/taller |  |  |  |  |

Bibliografía de apoyo
- Canet, Juan Miquel. Resistencia de Materiales y Estructuras. Ediciones CIMNE, edición digital, 2012.
- Material institucional de la cátedra: Unidad 01, Generalidades de Resistencia de Materiales.
- Plan anual de Resistencia de Materiales BTCC 2.º curso, elaborado a partir de capacidades del plan específico.
- Material complementario de Maestro de Obra Civil, utilizado como modelo para manual instructivo, actividades prácticas y seguridad en obra.
